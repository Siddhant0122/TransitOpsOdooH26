import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# For hackathon speed, SQLite works out of the box (no setup needed).
# Swap DATABASE_URL to a Postgres URL for production:
# postgresql://user:password@localhost:5432/transitops
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./transitops.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
