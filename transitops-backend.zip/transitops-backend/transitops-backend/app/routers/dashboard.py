import csv
import io
from typing import List, Optional
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database import get_db
from app import models, schemas, auth
from app.models import VehicleStatus, TripStatus, DriverStatus

router = APIRouter(tags=["dashboard"])


@router.get("/dashboard/kpis", response_model=schemas.DashboardKPIs)
def get_kpis(db: Session = Depends(get_db), current_user: models.User = Depends(auth.get_current_user)):
    total_vehicles = db.query(models.Vehicle).filter(models.Vehicle.status != VehicleStatus.RETIRED).count()
    available = db.query(models.Vehicle).filter(models.Vehicle.status == VehicleStatus.AVAILABLE).count()
    in_maintenance = db.query(models.Vehicle).filter(models.Vehicle.status == VehicleStatus.IN_SHOP).count()
    on_trip = db.query(models.Vehicle).filter(models.Vehicle.status == VehicleStatus.ON_TRIP).count()
    active_trips = db.query(models.Trip).filter(models.Trip.status == TripStatus.DISPATCHED).count()
    pending_trips = db.query(models.Trip).filter(models.Trip.status == TripStatus.DRAFT).count()
    drivers_on_duty = db.query(models.Driver).filter(models.Driver.status == DriverStatus.ON_TRIP).count()

    utilization = (on_trip / total_vehicles * 100) if total_vehicles else 0.0

    return schemas.DashboardKPIs(
        active_vehicles=total_vehicles,
        available_vehicles=available,
        vehicles_in_maintenance=in_maintenance,
        active_trips=active_trips,
        pending_trips=pending_trips,
        drivers_on_duty=drivers_on_duty,
        fleet_utilization_pct=round(utilization, 2),
    )


@router.get("/reports/vehicle-summary")
def vehicle_summary(db: Session = Depends(get_db), current_user: models.User = Depends(auth.get_current_user)):
    """Per-vehicle: fuel efficiency, operational cost, and ROI — feeds both the
    Reports & Analytics screen and the CSV export below."""
    vehicles = db.query(models.Vehicle).all()
    results = []
    for v in vehicles:
        fuel_cost = db.query(func.coalesce(func.sum(models.FuelLog.cost), 0.0)).filter(
            models.FuelLog.vehicle_id == v.id
        ).scalar()
        fuel_liters = db.query(func.coalesce(func.sum(models.FuelLog.liters), 0.0)).filter(
            models.FuelLog.vehicle_id == v.id
        ).scalar()
        maintenance_cost = db.query(func.coalesce(func.sum(models.MaintenanceLog.cost), 0.0)).filter(
            models.MaintenanceLog.vehicle_id == v.id
        ).scalar()
        distance = db.query(func.coalesce(func.sum(models.Trip.actual_distance), 0.0)).filter(
            models.Trip.vehicle_id == v.id, models.Trip.status == TripStatus.COMPLETED
        ).scalar()
        # Revenue isn't in the spec's entity list; treat as 0 unless you add a
        # per-trip revenue/rate field, then swap this out for a real sum.
        revenue = 0.0

        fuel_efficiency = (distance / fuel_liters) if fuel_liters else 0.0
        operational_cost = fuel_cost + maintenance_cost
        roi = ((revenue - operational_cost) / v.acquisition_cost) if v.acquisition_cost else 0.0

        results.append({
            "vehicle_id": v.id,
            "registration_number": v.registration_number,
            "fuel_efficiency_km_per_l": round(fuel_efficiency, 2),
            "operational_cost": round(operational_cost, 2),
            "distance_travelled_km": round(distance, 2),
            "roi": round(roi, 4),
        })
    return results


@router.get("/reports/export.csv")
def export_csv(db: Session = Depends(get_db), current_user: models.User = Depends(auth.get_current_user)):
    data = vehicle_summary(db=db, current_user=current_user)
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=[
        "vehicle_id", "registration_number", "fuel_efficiency_km_per_l",
        "operational_cost", "distance_travelled_km", "roi",
    ])
    writer.writeheader()
    writer.writerows(data)
    buffer.seek(0)

    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=transitops_report.csv"},
    )
