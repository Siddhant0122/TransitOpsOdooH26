from datetime import date
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.models import RoleName, DriverStatus

router = APIRouter(prefix="/drivers", tags=["drivers"])

# Fleet Manager + Safety Officer can manage drivers (safety officer owns compliance fields)
WRITE_ROLES = (RoleName.FLEET_MANAGER, RoleName.SAFETY_OFFICER)


@router.get("/", response_model=List[schemas.DriverOut])
def list_drivers(
    status_filter: Optional[DriverStatus] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    q = db.query(models.Driver)
    if status_filter:
        q = q.filter(models.Driver.status == status_filter)
    return q.all()


@router.get("/dispatch-pool", response_model=List[schemas.DriverOut])
def dispatch_pool(db: Session = Depends(get_db), current_user: models.User = Depends(auth.get_current_user)):
    """Drivers eligible for a new trip: Available, not suspended, license not expired."""
    return (
        db.query(models.Driver)
        .filter(models.Driver.status == DriverStatus.AVAILABLE)
        .filter(models.Driver.license_expiry >= date.today())
        .all()
    )


@router.get("/expiring-licenses", response_model=List[schemas.DriverOut])
def expiring_licenses(
    within_days: int = 30,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.RequireRole(RoleName.SAFETY_OFFICER, RoleName.FLEET_MANAGER)),
):
    from datetime import timedelta
    cutoff = date.today() + timedelta(days=within_days)
    return db.query(models.Driver).filter(models.Driver.license_expiry <= cutoff).all()


@router.post("/", response_model=schemas.DriverOut, status_code=201,
             dependencies=[Depends(auth.RequireRole(*WRITE_ROLES))])
def create_driver(payload: schemas.DriverCreate, db: Session = Depends(get_db)):
    if db.query(models.Driver).filter(
        models.Driver.license_number == payload.license_number
    ).first():
        raise HTTPException(status_code=400, detail="License number already registered")

    driver = models.Driver(**payload.model_dump())
    db.add(driver)
    db.commit()
    db.refresh(driver)
    return driver


@router.put("/{driver_id}", response_model=schemas.DriverOut,
            dependencies=[Depends(auth.RequireRole(*WRITE_ROLES))])
def update_driver(driver_id: str, payload: schemas.DriverUpdate, db: Session = Depends(get_db)):
    driver = db.query(models.Driver).filter(models.Driver.id == driver_id).first()
    if not driver:
        raise HTTPException(status_code=404, detail="Driver not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(driver, field, value)
    db.commit()
    db.refresh(driver)
    return driver


@router.delete("/{driver_id}", status_code=204,
               dependencies=[Depends(auth.RequireRole(RoleName.SAFETY_OFFICER))])
def suspend_driver(driver_id: str, db: Session = Depends(get_db)):
    driver = db.query(models.Driver).filter(models.Driver.id == driver_id).first()
    if not driver:
        raise HTTPException(status_code=404, detail="Driver not found")
    driver.status = DriverStatus.SUSPENDED
    db.commit()
