from datetime import date
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.models import RoleName, VehicleStatus, MaintenanceStatus

router = APIRouter(prefix="/maintenance", tags=["maintenance"])

WRITE_ROLES = (RoleName.FLEET_MANAGER,)


@router.get("/", response_model=List[schemas.MaintenanceOut])
def list_maintenance(db: Session = Depends(get_db), current_user: models.User = Depends(auth.get_current_user)):
    return db.query(models.MaintenanceLog).all()


@router.post("/", response_model=schemas.MaintenanceOut, status_code=201,
             dependencies=[Depends(auth.RequireRole(*WRITE_ROLES))])
def create_maintenance(payload: schemas.MaintenanceCreate, db: Session = Depends(get_db)):
    vehicle = db.query(models.Vehicle).filter(models.Vehicle.id == payload.vehicle_id).first()
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    if vehicle.status == VehicleStatus.ON_TRIP:
        raise HTTPException(status_code=400, detail="Cannot service a vehicle that is currently On Trip")

    log = models.MaintenanceLog(
        vehicle_id=payload.vehicle_id,
        maintenance_type=payload.maintenance_type,
        description=payload.description,
        cost=payload.cost,
        status=MaintenanceStatus.OPEN,
    )
    db.add(log)

    # Rule: creating an active maintenance record automatically sets vehicle to In Shop
    vehicle.status = VehicleStatus.IN_SHOP

    db.commit()
    db.refresh(log)
    return log


@router.post("/{log_id}/close", response_model=schemas.MaintenanceOut,
             dependencies=[Depends(auth.RequireRole(*WRITE_ROLES))])
def close_maintenance(log_id: str, db: Session = Depends(get_db)):
    log = db.query(models.MaintenanceLog).filter(models.MaintenanceLog.id == log_id).first()
    if not log:
        raise HTTPException(status_code=404, detail="Maintenance log not found")
    if log.status == MaintenanceStatus.CLOSED:
        raise HTTPException(status_code=400, detail="Maintenance log already closed")

    log.status = MaintenanceStatus.CLOSED
    log.end_date = date.today()

    # Rule: closing maintenance restores vehicle to Available, unless it's Retired.
    # Also don't reopen dispatch for a vehicle that has *other* open maintenance logs.
    other_open = (
        db.query(models.MaintenanceLog)
        .filter(models.MaintenanceLog.vehicle_id == log.vehicle_id)
        .filter(models.MaintenanceLog.id != log.id)
        .filter(models.MaintenanceLog.status == MaintenanceStatus.OPEN)
        .first()
    )
    if not other_open and log.vehicle.status != VehicleStatus.RETIRED:
        log.vehicle.status = VehicleStatus.AVAILABLE

    db.commit()
    db.refresh(log)
    return log
