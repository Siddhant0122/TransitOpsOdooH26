from datetime import date, datetime
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.models import RoleName, VehicleStatus, DriverStatus, TripStatus

router = APIRouter(prefix="/trips", tags=["trips"])

# Any authenticated operational role can create/dispatch trips; tune as needed.
DISPATCH_ROLES = (RoleName.FLEET_MANAGER, RoleName.DRIVER_ROLE)


@router.get("/", response_model=List[schemas.TripOut])
def list_trips(db: Session = Depends(get_db), current_user: models.User = Depends(auth.get_current_user)):
    return db.query(models.Trip).all()


@router.post("/", response_model=schemas.TripOut, status_code=201,
             dependencies=[Depends(auth.RequireRole(*DISPATCH_ROLES))])
def create_trip(
    payload: schemas.TripCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Creates a trip in Draft status. All eligibility rules are enforced here
    so an invalid trip can never be created, not just blocked at dispatch time."""

    vehicle = db.query(models.Vehicle).filter(models.Vehicle.id == payload.vehicle_id).first()
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    driver = db.query(models.Driver).filter(models.Driver.id == payload.driver_id).first()
    if not driver:
        raise HTTPException(status_code=404, detail="Driver not found")

    # Rule: Retired or In Shop vehicles must never appear in dispatch selection
    if vehicle.status != VehicleStatus.AVAILABLE:
        raise HTTPException(status_code=400, detail=f"Vehicle status is '{vehicle.status.value}', must be Available")

    # Rule: expired license or Suspended driver cannot be assigned
    if driver.status != DriverStatus.AVAILABLE:
        raise HTTPException(status_code=400, detail=f"Driver status is '{driver.status.value}', must be Available")
    if driver.license_expiry < date.today():
        raise HTTPException(status_code=400, detail="Driver's license has expired")

    # Rule: cargo weight must not exceed vehicle max load capacity
    if payload.cargo_weight > vehicle.max_load_capacity:
        raise HTTPException(
            status_code=400,
            detail=f"Cargo weight {payload.cargo_weight}kg exceeds vehicle capacity {vehicle.max_load_capacity}kg",
        )

    trip = models.Trip(
        source=payload.source,
        destination=payload.destination,
        vehicle_id=payload.vehicle_id,
        driver_id=payload.driver_id,
        created_by=current_user.id,
        cargo_weight=payload.cargo_weight,
        planned_distance=payload.planned_distance,
        status=TripStatus.DRAFT,
    )
    db.add(trip)
    db.commit()
    db.refresh(trip)
    return trip


@router.post("/{trip_id}/dispatch", response_model=schemas.TripOut,
             dependencies=[Depends(auth.RequireRole(*DISPATCH_ROLES))])
def dispatch_trip(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(models.Trip).filter(models.Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    if trip.status != TripStatus.DRAFT:
        raise HTTPException(status_code=400, detail=f"Cannot dispatch a trip in '{trip.status.value}' status")

    vehicle = trip.vehicle
    driver = trip.driver

    # Re-validate at dispatch time in case state changed since the trip was drafted
    # (e.g. another trip already claimed this vehicle/driver).
    if vehicle.status != VehicleStatus.AVAILABLE:
        raise HTTPException(status_code=409, detail="Vehicle is no longer available")
    if driver.status != DriverStatus.AVAILABLE:
        raise HTTPException(status_code=409, detail="Driver is no longer available")

    trip.status = TripStatus.DISPATCHED
    trip.dispatched_at = datetime.utcnow()
    vehicle.status = VehicleStatus.ON_TRIP
    driver.status = DriverStatus.ON_TRIP

    db.commit()
    db.refresh(trip)
    return trip


@router.post("/{trip_id}/complete", response_model=schemas.TripOut,
             dependencies=[Depends(auth.RequireRole(*DISPATCH_ROLES))])
def complete_trip(trip_id: str, payload: schemas.TripCompleteRequest, db: Session = Depends(get_db)):
    trip = db.query(models.Trip).filter(models.Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    if trip.status != TripStatus.DISPATCHED:
        raise HTTPException(status_code=400, detail=f"Cannot complete a trip in '{trip.status.value}' status")

    vehicle = trip.vehicle
    driver = trip.driver

    distance_travelled = payload.final_odometer - vehicle.odometer
    trip.actual_distance = max(distance_travelled, 0)
    trip.fuel_consumed = payload.fuel_consumed
    trip.status = TripStatus.COMPLETED
    trip.completed_at = datetime.utcnow()

    vehicle.odometer = payload.final_odometer
    vehicle.status = VehicleStatus.AVAILABLE
    driver.status = DriverStatus.AVAILABLE

    # auto-create a fuel log entry from trip completion
    if payload.fuel_consumed > 0:
        db.add(models.FuelLog(
            vehicle_id=vehicle.id, trip_id=trip.id,
            liters=payload.fuel_consumed, cost=0.0,
        ))

    db.commit()
    db.refresh(trip)
    return trip


@router.post("/{trip_id}/cancel", response_model=schemas.TripOut,
             dependencies=[Depends(auth.RequireRole(*DISPATCH_ROLES))])
def cancel_trip(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(models.Trip).filter(models.Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    if trip.status not in (TripStatus.DRAFT, TripStatus.DISPATCHED):
        raise HTTPException(status_code=400, detail=f"Cannot cancel a trip in '{trip.status.value}' status")

    was_dispatched = trip.status == TripStatus.DISPATCHED
    trip.status = TripStatus.CANCELLED

    # Rule: cancelling a dispatched trip restores vehicle and driver to Available
    if was_dispatched:
        trip.vehicle.status = VehicleStatus.AVAILABLE
        trip.driver.status = DriverStatus.AVAILABLE

    db.commit()
    db.refresh(trip)
    return trip
