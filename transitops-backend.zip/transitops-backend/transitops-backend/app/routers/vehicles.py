from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.models import RoleName, VehicleStatus

router = APIRouter(prefix="/vehicles", tags=["vehicles"])

# Fleet Manager owns the registry. Others can read.
WRITE_ROLES = (RoleName.FLEET_MANAGER,)


@router.get("/", response_model=List[schemas.VehicleOut])
def list_vehicles(
    status_filter: Optional[VehicleStatus] = None,
    type_filter: Optional[str] = None,
    region: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    q = db.query(models.Vehicle)
    if status_filter:
        q = q.filter(models.Vehicle.status == status_filter)
    if type_filter:
        q = q.filter(models.Vehicle.type == type_filter)
    if region:
        q = q.filter(models.Vehicle.region == region)
    return q.all()


@router.get("/dispatch-pool", response_model=List[schemas.VehicleOut])
def dispatch_pool(db: Session = Depends(get_db), current_user: models.User = Depends(auth.get_current_user)):
    """Vehicles eligible for a new trip: never Retired or In Shop, never already On Trip."""
    return db.query(models.Vehicle).filter(models.Vehicle.status == VehicleStatus.AVAILABLE).all()


@router.post("/", response_model=schemas.VehicleOut, status_code=201,
             dependencies=[Depends(auth.RequireRole(*WRITE_ROLES))])
def create_vehicle(payload: schemas.VehicleCreate, db: Session = Depends(get_db)):
    if db.query(models.Vehicle).filter(
        models.Vehicle.registration_number == payload.registration_number
    ).first():
        raise HTTPException(status_code=400, detail="Registration number must be unique")

    vehicle = models.Vehicle(**payload.model_dump())
    db.add(vehicle)
    db.commit()
    db.refresh(vehicle)
    return vehicle


@router.put("/{vehicle_id}", response_model=schemas.VehicleOut,
            dependencies=[Depends(auth.RequireRole(*WRITE_ROLES))])
def update_vehicle(vehicle_id: str, payload: schemas.VehicleUpdate, db: Session = Depends(get_db)):
    vehicle = db.query(models.Vehicle).filter(models.Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(vehicle, field, value)
    db.commit()
    db.refresh(vehicle)
    return vehicle


@router.delete("/{vehicle_id}", status_code=204,
               dependencies=[Depends(auth.RequireRole(*WRITE_ROLES))])
def retire_vehicle(vehicle_id: str, db: Session = Depends(get_db)):
    """Soft-delete: retire rather than hard-delete, to preserve trip/expense history."""
    vehicle = db.query(models.Vehicle).filter(models.Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    vehicle.status = VehicleStatus.RETIRED
    db.commit()
