"""
Run once after starting the app to create the four roles and a demo user
per role, so the frontend team can log in immediately without registering.

    python seed.py
"""
from app.database import SessionLocal, Base, engine
from app import models, auth

Base.metadata.create_all(bind=engine)
db = SessionLocal()

DEMO_USERS = [
    ("fleet.manager@transitops.dev", "Password123!", "Fay Fleet", models.RoleName.FLEET_MANAGER),
    ("driver@transitops.dev", "Password123!", "Dan Driver", models.RoleName.DRIVER_ROLE),
    ("safety@transitops.dev", "Password123!", "Sam Safety", models.RoleName.SAFETY_OFFICER),
    ("finance@transitops.dev", "Password123!", "Fin Analyst", models.RoleName.FINANCIAL_ANALYST),
]

for email, password, name, role_name in DEMO_USERS:
    role = db.query(models.Role).filter(models.Role.name == role_name).first()
    if not role:
        role = models.Role(name=role_name)
        db.add(role)
        db.flush()

    if not db.query(models.User).filter(models.User.email == email).first():
        db.add(models.User(
            email=email,
            password_hash=auth.hash_password(password),
            full_name=name,
            role_id=role.id,
        ))

db.commit()
print("Seeded roles + demo users (password for all: Password123!):")
for email, _, _, role_name in DEMO_USERS:
    print(f"  {email}  ->  {role_name.value}")
